#include<stdio.h>

int myplus(int a,int b);
int mymultiply(int a,int b);


