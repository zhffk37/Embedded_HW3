#include "calculator.h"

int main()
{
	int a=3,b=5;
	printf("%d+%d=%d\n",a,b,myplus(a,b));
	printf("%d*%d=%d\n",a,b,mymultiply(a,b));
	return 0;
}
