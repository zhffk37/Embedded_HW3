#include "calculator.h"

int myplus(int a,int b)
{
	printf("my plus called\n");
	return a+b;
}
