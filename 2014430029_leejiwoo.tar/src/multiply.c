#include"calculator.h"

int mymultiply(int a, int b)
{
	printf("my multiply called\n");
	return a*b;
}
